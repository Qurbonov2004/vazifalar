from django.urls import path
from .views import *

urlpatterns=[
    path('service',service_read),
    path('create_service',create_service),
    path('update_service',update_service),
    path('delete_service',delete_service),
    path('create_mashgulot',create_mashgulot),
    path('update_mashgulot',update_mashgulot),
    path('delete_mashgulot',delete_mashgulot),
    path('mashgulot_read',mashgulot_read),
    path('teacher_read',teacher_read),
    path('create_teacher',create_teacher),
    path('update_teacher',update_teacher),
    path('delete_teacher',delete_teacher),
    path('contact_read',contact_read),
    path('create_contact',create_contact),
    path('update_contact',update_contact),
    path('delete_contact',delete_contact),

]