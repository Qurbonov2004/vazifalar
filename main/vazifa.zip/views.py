from django.shortcuts import render 
from django.http import HttpResponse
from .models import Service,Mashgulot,Teacher,Contact_Us


def  service_read(request):
    services = Service.objects.all()
    print(services)
    return HttpResponse("service ishladi")


def create_service(request):
    servise = Service.objects.create(
        # service_icon='image.jpg',
        service_name='suzish',
        about_service='yaxshi'     )
    return HttpResponse('Data yaratilindi')


def update_service(request):
    service = Service.objects.get(service_name='yugurish')
    service.service_name='yugurish'
    service.about_service="zo'r"
    service.save()
    return HttpResponse("Ma'lumot yangilandi")

def delete_service(request):
    service = Service.objects.get(service_name='yugurish')
    service.delete()
    
    return HttpResponse("Ma'lumot o'chirildi")
    


def  mashgulot_read(request):
    mashgulot = Mashgulot.objects.all()
    print(mashgulot)
    return HttpResponse("tizim ishladi")

def create_mashgulot(request):
    mashgulot = Mashgulot.objects.create(
        mashgulot_nomi="suzish",
        davomiyligi="30 daqiqa",
        boshlanish_vaqti="08:00",
        tugash_vaqti="08:30",
        # mashgulot_icon="img.png",
        kuni="Dushanba"
    )
    return HttpResponse('tizim ishladi')

def update_mashgulot(request):
    mashgulot=Mashgulot.objects.get(mashgulot_nomi='suzish')
    mashgulot.mashgulot_nomi='yugurish',
    mashgulot.davomiyligi='45 daqiqa',
    mashgulot.boshlanish_vaqti='08:00',
    mashgulot.tugash_vaqti='08:45',
    mashgulot.kuni='Seshanba'
    mashgulot.save()
    return HttpResponse("tizim ishladi")

def delete_mashgulot(request):
    mashgulot = Mashgulot.objects.get(mashgulot_name='suzish')
    mashgulot.delete()
    return HttpResponse("Tizim ishladi")


def  teacher_read(request):
    teacher = Teacher.objects.all()
    print(teacher)
    return HttpResponse("tizim ishladi")

def create_teacher(request):
    teacher = Teacher.objects.create(
        name='Odil',
        haqida='bokschi'       
    )
    return HttpResponse('tizim ishladi')

def update_teacher(request):
    teacher=Teacher.objects.get(name='Odil')
    teacher.name='Olim',
    teacher.haqida='futbolchi'
    
    teacher.save()
    return HttpResponse("tizim ishladi")

def delete_teacher(request):
    teacher = Teacher.objects.get(name='Olim')
    teacher.delete()
    return HttpResponse("Tizim ishladi")



def  contact_read(request):
    contact = Contact_Us.objects.all()
    print(contact)
    return HttpResponse("tizim ishladi")

def create_contact(request):
    contact = Contact_Us.objects.create(
        first_name='Omadbek',
        last_name="Qurbonov",
        subject="suzish",
        email="qurbonov@gmail.com",
        message='assalomu alaykum',
        is_active=False
        
    )
    return HttpResponse('tizim ishladi')

def update_contact(request):
    contact=Contact_Us.objects.get(first_name='Omadbek')
    contact.first_name='Otabek',
    contact.last_name="Qudratov",
    contact.subject="suzish",
    contact.email="qudratov@gmail.com",
    contact.message='salom',
    contact.is_active=True
    contact.save()
    return HttpResponse("tizim ishladi")

def delete_contact(request):
    contact = Contact_Us.objects.get(first_name='Omadbek')
    contact.delete()
    return HttpResponse("Tizim ishladi")







